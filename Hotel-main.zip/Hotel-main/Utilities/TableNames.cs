namespace Hotel.Utilities;

public enum TableNames
{
    guest,
    staff,
    room,
    schedule,
}